from django.apps import AppConfig


class DistributorSalesConfig(AppConfig):
    name = 'distributor_sales'
