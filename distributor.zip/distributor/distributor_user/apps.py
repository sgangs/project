from django.apps import AppConfig


class DistributorUserConfig(AppConfig):
    name = 'distributor_user'
