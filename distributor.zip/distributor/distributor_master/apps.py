from django.apps import AppConfig


class DistributorMasterConfig(AppConfig):
    name = 'distributor_master'
