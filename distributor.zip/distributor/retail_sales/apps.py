from django.apps import AppConfig


class RetailSalesConfig(AppConfig):
    name = 'retail_sales'
