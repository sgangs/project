from django.apps import AppConfig


class DistributorInventoryConfig(AppConfig):
    name = 'distributor_inventory'
