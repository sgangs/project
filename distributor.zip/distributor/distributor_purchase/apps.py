from django.apps import AppConfig


class DistributorPurchaseConfig(AppConfig):
    name = 'distributor_purchase'
