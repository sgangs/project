from django.apps import AppConfig


class PayumoneyConfig(AppConfig):
    name = 'payumoney'
