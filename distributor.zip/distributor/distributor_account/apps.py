from django.apps import AppConfig


class DistributorAccountConfig(AppConfig):
    name = 'distributor_account'
