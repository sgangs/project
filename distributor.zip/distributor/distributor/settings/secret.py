
#Do not share this file

distributor_secret_key='cq_$7h-l5t0f!i1gi2*n3#n$7mn_n)9&$mscb1rh%(3qz3o*r0'

db_name="distributor"
# db_name="distributor_test"
db_username="postgres"
db_password="postgres"

