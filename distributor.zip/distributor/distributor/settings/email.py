
#Do not share this file


EMAIL_USE_TLS = True
EMAIL_HOST = "smtp.zoho.com"
EMAIL_PORT = 587
EMAIL_HOST_USER = "sayantan@techassisto.com"
EMAIL_HOST_PASSWORD = "n9kjc3x0a8p8"

